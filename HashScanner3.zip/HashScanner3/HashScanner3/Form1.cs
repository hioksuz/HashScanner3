﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HashScanner3
{
    public partial class HashScanner3 : Form
    {
        public HashScanner3()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            DialogResult result = folderBrowserDialog1.ShowDialog();
            if (result == DialogResult.OK)
            {
                textBox3.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string targetHash = textBox2.Text.ToLower();
            try
            {
                string[] allFiles = Directory.GetFiles(textBox3.Text, "*", SearchOption.AllDirectories);
                bool found = false;

                Parallel.ForEach(allFiles, (file, state) =>
                {
                    try
                    {
                        string fileHash = CalculateFileSHA256(file);
                        Console.WriteLine("Dosya Yolu: " + file);
                        Console.WriteLine("Hash Değeri: " + fileHash);

                        if (fileHash.Equals(targetHash))
                        {
                            Invoke(new Action(() =>
                            {
                                textBox1.AppendText("Dosya Bulundu:" + Environment.NewLine +
                                                     "Klasör: " + Path.GetDirectoryName(file) + Environment.NewLine +
                                                     "Dosya Adı: " + Path.GetFileName(file) + Environment.NewLine);
                            }));
                            found = true;
                            state.Stop();
                        }
                    }
                    catch (UnauthorizedAccessException ex)
                    {
                        Invoke(new Action(() =>
                        {
                            textBox1.AppendText($"Erişim Hatası: {ex.Message}. Dosya: {file}" + Environment.NewLine);
                        }));
                    }
                    catch (Exception ex)
                    {
                        // Genel hatalar için hata mesajı ekleme
                        Invoke(new Action(() =>
                        {
                            textBox1.AppendText($"Bilinmeyen Hata: {ex.Message}. Dosya: {file}" + Environment.NewLine);
                        }));
                    }
                });

                if (!found)
                {
                    MessageBox.Show("Belirtilen SHA-256 Hash Koduna sahip dosya bulunamadı.", "Dosya Bulunamadı", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bir hata oluştu: " + ex.Message, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private string CalculateFileSHA256(string filePath)
        {
            using (SHA256 sha256 = SHA256.Create())
            {
                using (FileStream fileStream = File.OpenRead(filePath))
                {
                    byte[] hashBytes = sha256.ComputeHash(fileStream);
                    return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
                }
            }
        }
    }
}
